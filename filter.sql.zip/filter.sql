-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Jul 06, 2016 at 11:49 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `filter`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `full_name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `from_date`, `to_date`, `full_name`, `email`, `city`) VALUES
(1, '2011-11-22', '2011-11-26', 'Aaron P. Holt', 'AaronPHolt@teleworm.com', 'London'),
(2, '2011-11-23', '2011-11-26', 'Calvin N. Harwood', 'CalvinNHarwood@teleworm.com', 'New York'),
(3, '2011-11-20', '2011-12-14', 'Richard J. Mayo', 'RichardJMayo@teleworm.com', 'London'),
(4, '2011-11-11', '2011-11-30', 'Melissa L. Haffey', 'MelissaLHaffey@teleworm.com', 'London'),
(5, '2011-12-06', '2011-12-15', 'Orlando P. Lucas', 'OrlandoPLucas@teleworm.com', 'New York'),
(6, '2012-11-07', '2011-12-16', 'Tara R. Hale', 'TaraRHale@teleworm.com', 'Paris'),
(7, '2011-12-19', '2011-12-23', 'Stuart D. Jordan', 'StuartDJordan@teleworm.com', 'Paris'),
(8, '2011-12-25', '2011-12-30', 'John R. Howell', 'JohnRHowell@teleworm.com', 'Paris'),
(9, '2011-12-13', '2011-12-30', 'Nick P. Bueche', 'NickPBueche@teleworm.com', 'New York'),
(10, '2011-12-29', '2012-01-04', 'Solomon S. Moreno', 'SolomonSMoreno@teleworm.com', 'Paris');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
